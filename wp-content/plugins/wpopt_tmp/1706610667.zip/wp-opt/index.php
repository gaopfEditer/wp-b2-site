<?php
/*
Plugin Name: WPOPT
Plugin URI: https://www.lovestu.com/wpopt.html
Description: WPOPT-WordPress高级优化插件
Version: 2.0.8
Requires at least: 5.7
Tested up to: 5.8
Requires PHP: 5.6
Author: applek
Author URI: https://www.lovestu.com/
*/

namespace wp_opt;



require_once WP_PLUGIN_DIR . '/wp-opt/core/Config.php';





